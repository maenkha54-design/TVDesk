# TV Desk — واجهة HOME لـ Xiaomi Mi TV Stick

سطح مكتب بتصميم يجمع Windows 11 وSamsung DeX، يعمل كـ **واجهة HOME حقيقية** على Android TV 9 (SDK 28، ARM64، رام 2GB).
مبني بـ Views عادية + RecyclerView فقط (بدون Compose وبدون AppCompat) ليبقى خفيفًا وسريعًا.

## المراحل

| المرحلة | المحتوى | الحالة |
|---|---|---|
| 1 | هيكل المشروع، Manifest كواجهة HOME، سطح المكتب بأيقونات كل التطبيقات، شريط المهام (زر ابدأ + ساعة + تاريخ)، التنقل بالريموت، تحديث القائمة عند تثبيت/حذف تطبيق | ✅ مكتوبة |
| 2 | قائمة ابدأ (كل التطبيقات، بحث، أزرار الطاقة)، زر Menu في الريموت، الضغط المطوّل على أيقونة (فتح معلومات التطبيق / إلغاء التثبيت) | قادمة |
| 3 | لوحة الإعدادات السريعة (واي فاي، بلوتوث، الصوت، الشاشة، الشبكة) عبر شاشات إعدادات النظام | قادمة |
| 4 | الخلفيات القابلة للتغيير (تدرجات جاهزة + صورة مخصصة)، حفظ الإعدادات، تثبيت التطبيقات على سطح المكتب وترتيبها | قادمة |
| 5 | صقل الأداء، اختصارات الريموت الكاملة، توقيع نسخة Release، دليل التعيين كواجهة افتراضية | قادمة |

## هيكل المشروع

```
TVDesk/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradlew, gradlew.bat, gradle/wrapper/
└── app/
    ├── build.gradle.kts          (minSdk 24, targetSdk 28, compileSdk 34)
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml   (HOME + DEFAULT + LEANBACK_LAUNCHER)
        ├── java/com/tvdesk/launcher/
        │   ├── data/AppInfo.kt, AppRepository.kt
        │   └── ui/MainActivity.kt, AppAdapter.kt
        └── res/
            ├── layout/  activity_main, taskbar, item_app
            ├── drawable/ wallpaper_default, bg_focusable, ic_start, ic_launcher, banner
            └── values/, values-ar/  (نصوص عربي/إنجليزي، ألوان، ثيم داكن)
```

## البناء

المتطلبات: JDK 17 وAndroid SDK (منصة 34). الأسهل: افتح المجلد في **Android Studio** واضغط Build ← Build APK.

من سطر الأوامر (مع ضبط `ANDROID_HOME` أو ملف `local.properties` فيه `sdk.dir=...`):

```
./gradlew assembleDebug
```

الناتج: `app/build/outputs/apk/debug/app-debug.apk`

## التثبيت على Mi TV Stick

1. على الجهاز: الإعدادات ← تفضيلات الجهاز ← حول ← اضغط على "Build" سبع مرات لتفعيل وضع المطور، ثم فعّل **USB debugging** (أو تصحيح الشبكة).
2. من الكمبيوتر على نفس الشبكة:

```
adb connect <عنوان-IP-للجهاز>:5555
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## تعيينه كواجهة افتراضية

افتح التطبيق من صف التطبيقات (يظهر باسم "TV Desk")، ثم اضغط زر Home في الريموت؛ إن ظهرت نافذة اختيار الواجهة فاختر TV Desk ثم "دائمًا".

إن لم تظهر النافذة (بعض أجهزة Android TV تثبّت واجهتها الرسمية)، جرّب:

```
adb shell cmd package set-home-activity com.tvdesk.launcher/.ui.MainActivity
```

> هذه الخطوة لم تُجرَّب على جهاز Mi TV Stick فعليًا؛ إن لم تعمل على إصدارك فأخبرني بالنتيجة لنعدّلها.

## التراجع إذا حدث خلل

لا تعطّل واجهة النظام الأصلية قبل التأكد أن TV Desk يعمل جيدًا. للرجوع لواجهة النظام:

```
adb uninstall com.tvdesk.launcher
```

## ملاحظات التحكم بالريموت (المرحلة 1)

- الأسهم: التنقل بين الأيقونات وشريط المهام (التركيز يظهر بإطار أزرق).
- OK: فتح التطبيق أو زر ابدأ.
- Home: العودة لأول أيقونة. Back: لا يفعل شيئًا (الواجهة لا تُغلق نفسها).
- زر ابدأ حاليًا يعرض رسالة فقط؛ القائمة الفعلية في المرحلة 2.
