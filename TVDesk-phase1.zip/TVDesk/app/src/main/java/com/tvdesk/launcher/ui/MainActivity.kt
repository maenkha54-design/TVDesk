package com.tvdesk.launcher.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.tvdesk.launcher.R
import com.tvdesk.launcher.data.AppInfo
import com.tvdesk.launcher.data.AppRepository
import java.util.concurrent.Executors

/**
 * The HOME screen: desktop icon grid + taskbar.
 * Plain [Activity] (no AppCompat) to stay light on a 2 GB device.
 */
class MainActivity : Activity() {

    private lateinit var grid: RecyclerView
    private lateinit var adapter: AppAdapter

    private val worker = Executors.newSingleThreadExecutor()
    private var initialFocusDone = false

    private val reloadRunnable = Runnable { reloadApps() }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            // Installs and updates arrive in bursts: wait a moment, then reload once.
            grid.removeCallbacks(reloadRunnable)
            grid.postDelayed(reloadRunnable, 600)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        grid = findViewById(R.id.desktop_grid)
        val metrics = resources.displayMetrics
        val cellWidthPx = (132 * metrics.density).toInt()
        val usableWidthPx = metrics.widthPixels - grid.paddingLeft - grid.paddingRight
        val spanCount = (usableWidthPx / cellWidthPx).coerceIn(4, 12)
        grid.layoutManager = GridLayoutManager(this, spanCount)
        grid.setHasFixedSize(true)

        adapter = AppAdapter(::launch)
        grid.adapter = adapter

        findViewById<View>(R.id.start_button).setOnClickListener {
            // Phase 2 replaces this with the real Start menu.
            Toast.makeText(this, R.string.start_menu_soon, Toast.LENGTH_SHORT).show()
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)

        reloadApps()
    }

    /** Pressing the remote's Home button while we are already on top lands here. */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == Intent.ACTION_MAIN && intent.hasCategory(Intent.CATEGORY_HOME)) {
            focusFirstIcon()
        }
    }

    /** A launcher must never close itself, so Back does nothing. */
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // Intentionally empty.
    }

    override fun onDestroy() {
        grid.removeCallbacks(reloadRunnable)
        unregisterReceiver(packageReceiver)
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun reloadApps() {
        if (worker.isShutdown) return
        val appContext = applicationContext
        worker.execute {
            val apps = AppRepository.loadLaunchableApps(appContext)
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                adapter.submit(apps)
                if (!initialFocusDone && apps.isNotEmpty()) {
                    initialFocusDone = true
                    focusFirstIcon()
                }
            }
        }
    }

    private fun focusFirstIcon() {
        grid.scrollToPosition(0)
        // Posted after the pending layout pass, so the first icon view exists by then.
        grid.post { grid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    private fun launch(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN)
            .setClassName(app.packageName, app.activityName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, getString(R.string.launch_failed, app.label), Toast.LENGTH_SHORT).show()
        } catch (e: SecurityException) {
            Toast.makeText(this, getString(R.string.launch_failed, app.label), Toast.LENGTH_SHORT).show()
        }
    }
}
