package com.tvdesk.launcher.data

import android.content.Context
import android.content.Intent

/** Reads the list of launchable apps from the system. Call off the main thread (icons are loaded here). */
object AppRepository {

    fun loadLaunchableApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val ownPackage = context.packageName
        val byPackage = LinkedHashMap<String, AppInfo>()

        // Leanback (TV) entries first so TV-specific activities win over phone ones.
        val categories = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        for (category in categories) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (info in pm.queryIntentActivities(query, 0)) {
                val activity = info.activityInfo ?: continue
                if (activity.packageName == ownPackage) continue
                if (byPackage.containsKey(activity.packageName)) continue
                byPackage[activity.packageName] = AppInfo(
                    label = info.loadLabel(pm).toString(),
                    packageName = activity.packageName,
                    activityName = activity.name,
                    icon = info.loadIcon(pm)
                )
            }
        }

        return byPackage.values.sortedBy { it.label.lowercase() }
    }
}
