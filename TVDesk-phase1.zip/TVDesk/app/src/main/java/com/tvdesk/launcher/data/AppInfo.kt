package com.tvdesk.launcher.data

import android.graphics.drawable.Drawable

/** One launchable app shown as an icon on the desktop. */
data class AppInfo(
    val label: String,
    val packageName: String,
    val activityName: String,
    val icon: Drawable
)
