# Project-specific ProGuard/R8 rules.
# The launcher uses no reflection, so no extra keep rules are needed yet.
