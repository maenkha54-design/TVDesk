plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tvdesk.launcher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tvdesk.launcher"
        minSdk = 24
        // The target device runs Android 9 (SDK 28). Targeting 28 also keeps the
        // package-visibility rules of Android 11+ out of the way for a launcher.
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        // targetSdk 28 triggers "expired target SDK" lint noise; this APK is
        // sideloaded, not published on Google Play.
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // Deliberately minimal: plain Views + RecyclerView keep the APK small and
    // fast on a 2 GB device (no Compose, no AppCompat).
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
